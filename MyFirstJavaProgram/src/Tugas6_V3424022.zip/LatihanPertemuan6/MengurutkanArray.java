package LatihanPertemuan6;

import java.util.Arrays;

public class MengurutkanArray {
  public static void main(String[] args) {
    int[] array1 = { 2, 4, 6, 8, 10 };
    int[] array2 = { 1, 3, 5, 7, 9 };
    int[] hasil = Arrays.copyOf(array1, array1.length + array2.length);
    System.arraycopy(array2, 0, hasil, array1.length, array2.length);
    hasil = Urutkan(hasil);

    System.out.println(Arrays.toString(hasil));
  }

  public static int[] Urutkan(int[] array) {
    int[] hasil = Arrays.copyOf(array, array.length);
    int temp;

    for (int i = 1; i < hasil.length; i++) {
      if (array[i - 1] > array[i]) {
        for (int j = 1; j < hasil.length; j++) {
          if (hasil[j - 1] > hasil[j]) {
            temp = hasil[j - 1];
            hasil[j - 1] = hasil[j];
            hasil[j] = temp;
          }
        }
        return Urutkan(hasil);
      }
    }

    return hasil;
  }
}
