package LatihanPertemuan6;

import java.util.Scanner;

public class MenentukanGanjilGenap {
  static Scanner sc = new Scanner(System.in);

  public static void main(String[] arge) {
    System.out.print("Masukkan angka: ");
    int input = sc.nextInt();
    if (input < 0) {
      System.out.println("Angka yang dimasukkan tidak boleh bernilai negatif");
    } else {
      if (input % 2 == 0) {
        System.out.println("Angka yang dimasukkan adalah bilangan genap");
      } else {
        System.out.println("Angka yang dimasukkan adalah bilangan ganjil");
      }
    }
  }
}
