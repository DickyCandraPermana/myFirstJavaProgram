package LatihanPertemuan6;

/**
 *
 * @author candr
 */
public class MaksimalInteger {
  public static void main(String[] args) {
    int[] array = { 3, 1, 9 };
    int hasil = 0;
    for (int i = 0; i < array.length; i++) {
      if (array[i] > hasil) {
        hasil = array[i];
      }
    }
    System.out.println("Nilai terbesar adalah: " + hasil);
  }
}
