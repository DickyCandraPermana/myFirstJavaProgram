// package pertemuan5;

public class tukar {
  public static void main(String[] args) {

    // Deklarasi variabel
    int a = 10;
    int b = 20;
    int c;

    // Cek awal data
    System.out.println("Nilai a: " + a);
    System.out.println("Nilai b: " + b);

    // Proses data
    c = a;
    a = b;
    b = c;

    // Output data
    System.out.println("Nilai a: " + a);
    System.out.println("Nilai b: " + b);
  }
}