// package pertemuan5;

import java.util.Scanner;

public class segitiga {
  static Scanner sc = new Scanner(System.in);

  public static void main(String[] args) {
    double alas, tinggi, luas, keliling, sisiMiring;

    try {
      System.out.print("Masukkan alas segitiga: ");
      alas = sc.nextDouble();
      System.out.print("Masukkan tinggi segitiga: ");
      tinggi = sc.nextDouble();
      luas = (alas * tinggi) / 2;
      sisiMiring = Math.sqrt(Math.pow((alas / 2), 2) + Math.pow(tinggi, 2));
      keliling = alas + (2 * sisiMiring);
      System.out.println("Luas segitiga: " + luas);
      System.out.println("Keliling segitiga: " + keliling);
    } catch (NumberFormatException e) {
      System.out.println("Inputan harus berupa angka");
    }
  }
}
